const PASSWORD = "CAMBIO2026";

function login() {
  const pass = document.getElementById("pass").value;
  if (pass === PASSWORD) {
    document.getElementById("panel").style.display = "block";
    cargarDatos();
  } else {
    alert("Acceso denegado");
  }
}

function cargarDatos() {
  document.getElementById("actual").innerText =
    `1 BRL = ${COTIZACION_BRL_PYG} PYG (${FECHA_COTIZACION})`;

  const ul = document.getElementById("historial");
  HISTORIAL.forEach(h => {
    const li = document.createElement("li");
    li.textContent = h;
    ul.appendChild(li);
  });
}
