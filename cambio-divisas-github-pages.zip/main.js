document.getElementById("fecha").innerText =
  `Cotización válida para: ${FECHA_COTIZACION}`;

document.getElementById("cotizacion").innerText =
  `1 BRL = ${COTIZACION_BRL_PYG.toLocaleString()} PYG`;

function convertir() {
  const monto = parseFloat(document.getElementById("monto").value);
  const tipo = document.getElementById("tipo").value;

  if (isNaN(monto) || monto <= 0) {
    alert("Ingrese un monto válido");
    return;
  }

  let resultado = 0;

  if (tipo === "PYGtoBRL") {
    resultado = (monto / COTIZACION_BRL_PYG) - TASA_ENTREGA_BRL;
    if (resultado < 0) resultado = 0;
    document.getElementById("resultado").innerText =
      `${resultado.toFixed(2)} BRL`;
  } else {
    resultado = (monto - TASA_ENTREGA_BRL) * COTIZACION_BRL_PYG;
    if (resultado < 0) resultado = 0;
    document.getElementById("resultado").innerText =
      `${resultado.toLocaleString()} PYG`;
  }
}
